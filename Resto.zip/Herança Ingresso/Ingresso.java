
public class Ingresso{
	
	protected Double valor;
	
	public Double mostraValor(){
		
		return valor;
	}
	
	public Ingresso(Double valor){
		this.valor = valor;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}
}

